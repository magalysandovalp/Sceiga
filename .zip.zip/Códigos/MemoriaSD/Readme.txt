Conexi�n de patillas

https://github.com/sparkfun/OpenLog/wiki/datasheet

El siguiente archivo contiene el funcionamiento b�sico del openlog