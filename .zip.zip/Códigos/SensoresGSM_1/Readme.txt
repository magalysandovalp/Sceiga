La programacion incluye:
	Luz
	Humedad
	Presion
	Temperatura
	Aceleracion
	GSM Shield
La version con el acelerometro aun no ha sido probada en caliente, solamente ha sido compilada.
