Esta versi�n incluye los siguientes sensores:
1. Temperatura
2. Humedad
3. Luz
4. Compas
5. Presion
