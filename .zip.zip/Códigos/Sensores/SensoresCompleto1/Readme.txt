El codigo trae los siguientes sensores: humedad, temperatura, luz, presion, aceleracion y direccion. 
Guarda en la tarjeta SD con el OpenLog y crea un archivo .csv que se puede abrir En Excel.
Contiene tambien el gps.
Se adjunta el conjunto de librer�as presentes a la hora de compilar el programa
