ARDUGSMLite
===========

A library to use the GSM Module SM5100B

version 0.0.1